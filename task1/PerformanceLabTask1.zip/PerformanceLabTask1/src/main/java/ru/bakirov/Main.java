package ru.bakirov;

public class Main {

    public static void main(String[] args) {

        Task1 task1 = new Task1();
        System.out.println(task1.task1());

    }
}
